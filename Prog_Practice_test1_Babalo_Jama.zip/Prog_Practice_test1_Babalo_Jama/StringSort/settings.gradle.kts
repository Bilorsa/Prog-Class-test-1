rootProject.name = "StringSort"

