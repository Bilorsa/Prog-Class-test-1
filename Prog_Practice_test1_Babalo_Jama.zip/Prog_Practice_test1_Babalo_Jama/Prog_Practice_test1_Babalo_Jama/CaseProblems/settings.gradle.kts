rootProject.name = "CaseProblems"

