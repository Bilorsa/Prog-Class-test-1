rootProject.name = "CollegeCourse"

