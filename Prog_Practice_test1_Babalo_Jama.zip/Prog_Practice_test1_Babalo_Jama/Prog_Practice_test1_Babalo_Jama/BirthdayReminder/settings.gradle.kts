rootProject.name = "BirthdayReminder"

