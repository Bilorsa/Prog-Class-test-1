rootProject.name = "MeanMedian"

