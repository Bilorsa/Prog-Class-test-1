rootProject.name = "DaysOfWeek"

