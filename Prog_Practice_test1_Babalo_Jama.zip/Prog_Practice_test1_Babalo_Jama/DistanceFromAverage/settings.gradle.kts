rootProject.name = "DistanceFromAverage"

